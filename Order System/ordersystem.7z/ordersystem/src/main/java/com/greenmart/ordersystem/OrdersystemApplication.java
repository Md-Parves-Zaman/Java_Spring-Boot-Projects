package com.greenmart.ordersystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrdersystemApplication.class, args);
    }
}
